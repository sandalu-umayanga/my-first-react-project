import React from 'react'
import "./ComponentCss/Footer.css";

export default function Footer() {
  return (
    <div className="container-fluid footerMain mt-3">
      <div className="row">
        <div className="col">
          <h1>Footer</h1>
        </div>
      </div>
    </div>
  );
}
